﻿using TorannMagic;
using AbilityUser;
using RimWorld;
using Verse;

namespace MF_GuiYi
{
		[DefOf]
        public static class MF_GYDefOf
    {
        public static TMAbilityDef MF_Fire;
        public static TMAbilityDef MF_Frost;
        public static TMAbilityDef MF_Earth;
        public static TMAbilityDef MF_Lightning;
        public static TMAbilityDef MF_Bright;
        public static TMAbilityDef MF_Element;
        public static DamageDef TM_Arcane;
        public static DamageDef TM_Overwhelm;
        public static ThingDef MF_Sun;
        public static JobDef MF_Use;
    }
}
