﻿using RimWorld;
using System.Collections.Generic;
using TorannMagic;
using Verse;
using Verse.AI;

namespace MF_GuiYi
{
    class MF_Building : Building
    {
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn myPawn)
        {
            CompAbilityUserMagic comp = myPawn.GetComp<CompAbilityUserMagic>();
            CompAbilityUserMight comp2 = myPawn.GetComp<CompAbilityUserMight>();
            List<FloatMenuOption> list = new List<FloatMenuOption>();
            if (!comp.IsMagicUser&&!comp2.IsMightUser) 
            {
                list.Add(new FloatMenuOption("MF_Job".Translate(), delegate ()
                {
                    Job job = new Job(MF_GYDefOf.MF_Use, this);
                    myPawn.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }));
            }
            return list;
        }
    }
}
