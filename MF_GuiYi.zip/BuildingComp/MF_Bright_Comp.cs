﻿using System;
using RimWorld;
using TorannMagic;
using Verse;
using System.Collections.Generic;
using System.Linq;

namespace MF_GuiYi
{
    class MF_Bright_Comp : ThingComp
    {
        public override void CompTick()
        {
            base.CompTick();
            age++;
            if (age > time)
            {
                for (int i = 0; i < parent.Map.mapPawns.AllPawns.Count; i++)
                {
                    Pawn Pawn = parent.Map.mapPawns.AllPawns[i];
                    DamageInfo D = new DamageInfo(MF_GYDefOf.TM_Overwhelm, 10, 0f, 0f, parent, null, null, DamageInfo.SourceCategory.ThingOrUnknown, Pawn);
                    if (Pawn != null)
                    {
                        bool flag = Pawn.def == TorannMagicDefOf.TM_SkeletonLichR || Pawn.def == TorannMagicDefOf.TM_GiantSkeletonR || Pawn.def == TorannMagicDefOf.TM_SkeletonR
                        || Pawn.def == TorannMagicDefOf.TM_LesserDemonR || Pawn.def == TorannMagicDefOf.TM_DemonR;
                        bool flag3 = Pawn.Position.InHorDistOf(parent.Position, 25f);
                        if (flag && flag3)
                        {
                          Pawn.TakeDamage(D);
                        }
                        if (!Pawn.NonHumanlikeOrWildMan()) 
                        {
                            bool flag2 = Pawn.story.traits.HasTrait(TorannMagicDefOf.Lich) || Pawn.story.traits.HasTrait(TorannMagicDefOf.Necromancer)|| Pawn.story.traits.HasTrait(TorannMagicDefOf.Undead);
                            if (flag2&& flag3) 
                            {
                                Pawn.TakeDamage(D);
                            }
                        }
                        if (Pawn.Faction == parent.Faction && flag3) 
                        {
                            IEnumerator<Hediff_Injury> HD = Pawn.health.hediffSet.GetInjuriesTendable().GetEnumerator();
                            if (HD != null)
                            {
                                if (HD.MoveNext())
                                {
                                    HD.Current.Severity -= 10;
                                }
                            }
                        }
                    }
                }
                age = 0;
            }
        }
        public int time = 100;
        public int age = 0;
    }
}
