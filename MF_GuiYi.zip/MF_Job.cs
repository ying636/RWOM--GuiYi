﻿using TorannMagic;
using RimWorld;
using Verse;
using Verse.AI;
using System.Collections.Generic;
using UnityEngine;

namespace MF_GuiYi
{
    public class MF_Job : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }
		protected override IEnumerable<Toil> MakeNewToils()
		{
			this.FailOnDestroyedOrNull(TargetIndex.A);
			Toil reserveTargetA = Toils_Reserve.Reserve(TargetIndex.A, 1, -1, null);
			yield return reserveTargetA;
			Thing T = TargetA.Thing;
			IntVec3 Pos = T.Position;
			IntVec3 pos2 = T.Position;
			Map Map = T.Map;
			Pos.z -= 3;

			Toil toil = new Toil
			{
				initAction = delegate ()
				{
				},

			tickAction = delegate ()
			{
				age++;
				TM_MoteMaker.ThrowGenericMote(TorannMagicDefOf.Mote_Arcane, T.DrawPos, T.Map, Rand.Range(0.4f, 0.6f), Rand.Range(0.1f, 0.2f), 0.01f, 1f, 300, 3.5f, 180f, 0f);
				if (age > durationTicks)
				{
					EndJobWith(JobCondition.Succeeded);
					T.Destroy(DestroyMode.Vanish);
					pawn.story.traits.allTraits.Add(new Trait(TraitDef.Named("MF_ManaDevourer"), 0, false));
					Thing T2 = ThingMaker.MakeThing(ThingDef.Named("MF_Powerlessaltar"), null);
					GenSpawn.Spawn(T2, pos2, Map);
				}
			},
				defaultCompleteMode = ToilCompleteMode.Never
			};

			toil.WithProgressBar(TargetIndex.A, delegate
			{
				bool flag = this.pawn.DestroyedOrNull() || this.pawn.Dead || this.pawn.Downed;
				float result;
				if (flag)
				{
					result = 1f;
				}
				else
				{
					result = 1f - (float)age / (float)durationTicks;
				}
				return result;
			}, false, 0f);

			yield return Toils_Goto.GotoCell(Pos, PathEndMode.OnCell);
			yield return toil;

			yield break;
		}
		public int age = 0;
		public int durationTicks = 500;
	}
}
