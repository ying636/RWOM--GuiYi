﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_Projecting : Projectile_Ability
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn user = hitThing as Pawn;
            if (Hediff_Name() != null)
            {
                Hediff H1 = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named(Hediff_Name()));
                if (H1 != null)
                {
                    //烈焰
                    if (H1.def.defName== "MF_Fire") 
                    {
                        MF_Fire_Hediff C1 = H1.TryGetComp<MF_Fire_Hediff>();
                        if (C1.isProjected == true)
                        {
                            C1.isProjected = false;
                        }
                        else
                        {
                            C1.isProjected = true;
                        }
                    }
                    //寒霜
                    if (H1.def.defName == "MF_Frost")
                    {
                        MF_Frost_Hediff_Comp C1 = H1.TryGetComp<MF_Frost_Hediff_Comp>();
                        if (C1.isProjected == true)
                        {
                            C1.isProjected = false;
                        }
                        else
                        {
                            C1.isProjected = true;
                        }
                    }
                    //?

                }


            }
            base.Destroy(DestroyMode.Vanish); ;
        }
        public string Hediff_Name()
        {
               string H1 = this.def.defName.Substring(14);
               return H1;
        }
     }
}
