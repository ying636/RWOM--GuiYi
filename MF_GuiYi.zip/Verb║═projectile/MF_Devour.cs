﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;
using Verse.AI;

namespace MF_GuiYi
{
    public class MF_Devour : Projectile_Ability
    {
        private void Mana_Add()
        {
            Pawn user = this.launcher as Pawn;
            Hediff HD = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Mana_Pure"));
            MF_Mana MF_Mana = HD as MF_Mana;
            MF_Mana.Severity += 0.01f;
        }
        protected override void Impact(Thing hitThing)
        {
            Pawn pawn = this.launcher as Pawn;
            Pawn pawn2 = hitThing as Pawn;
            Hediff Mana = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Mana_Pure"));
            CompAbilityUserMagic comp = pawn.GetComp<CompAbilityUserMagic>();
            CompAbilityUserMagic Target_Comp = pawn2.GetComp<CompAbilityUserMagic>();
            MF_Mana Comp_Mana = Mana as MF_Mana;
         
            //焰

            if (pawn2.story.traits.HasTrait(TraitDef.Named("InnerFire")))
            {
                AddHD_Fire(pawn,pawn2,comp);
                Mana_Add();
            }

            //霜

            if (pawn2.story.traits.HasTrait(TraitDef.Named("HeartOfFrost")))
            {
                AddHD_Frost(pawn, pawn2, comp);
                Mana_Add();
            }

            //其他

            else
            {
                bool flag = Target_Comp.IsMagicUser;
                if (!flag)
                {
                    Comp_Mana.Severity += 0.01f;

                }
                else
                {
                    Mana_Add();
                    killpawn(pawn2);
                }
            }
            base.Destroy(DestroyMode.Vanish);
        }
        private void killpawn(Pawn pawn) 
        {
            CompAbilityUserMagic Target_Comp = pawn.GetComp<CompAbilityUserMagic>();
            Target_Comp.MagicUserLevel = 1;
            Target_Comp.MagicUserXP = 1;
            Target_Comp.MagicData.MagicAbilityPoints = 0;
            pawn.Kill(null, null);
        }

        //焰

        private void AddHD_Fire(Pawn pawn,Pawn pawn1, CompAbilityUserMagic comp)
        {
            if (!pawn.health.hediffSet.HasHediff(HediffDef.Named("MF_Fire")))
            {
                pawn.health.AddHediff(HediffDef.Named("MF_Fire"), null, null, null);
                int i = 0;
                while (i < comp.MagicData.AllMagicPowers.Count)
                {
                    TMAbilityDef tmabilityDef = (TMAbilityDef)comp.MagicData.AllMagicPowers[i].abilityDef;
                    if (tmabilityDef == MF_GYDefOf.MF_Fire || tmabilityDef == TorannMagicDefOf.TM_Firebolt)
                    {
                        bool flag9 = !comp.MagicData.AllMagicPowers[i].learned;
                        if (flag9)
                        {
                            comp.MagicData.AllMagicPowers[i].learned = true;
                            bool shouldInitialize = tmabilityDef.shouldInitialize;
                            if (shouldInitialize)
                            {
                                comp.RemovePawnAbility(tmabilityDef);
                                comp.AddPawnAbility(tmabilityDef, true, -1f);
                            }
                            comp.InitializeSpell();
                            i++;
                        }
                    }
                    i++;
                }
            }
            else
            {
                Hediff HD_F = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Fire"));
                HD_F.Severity += 0.3f;
            }
            killpawn(pawn1);
        }

        //霜

        private void AddHD_Frost(Pawn pawn, Pawn pawn1, CompAbilityUserMagic comp)
        {
            if (!pawn.health.hediffSet.HasHediff(HediffDef.Named("MF_Frost")))
            {
                pawn.health.AddHediff(HediffDef.Named("MF_Frost"), null, null, null);
                int i = 0;
                while (i < comp.MagicData.AllMagicPowers.Count)
                {
                    TMAbilityDef tmabilityDef = (TMAbilityDef)comp.MagicData.AllMagicPowers[i].abilityDef;
                    if (tmabilityDef == MF_GYDefOf.MF_Frost || tmabilityDef == TorannMagicDefOf.TM_Icebolt)
                    {
                        bool flag9 = !comp.MagicData.AllMagicPowers[i].learned;
                        if (flag9)
                        {
                            comp.MagicData.AllMagicPowers[i].learned = true;
                            bool shouldInitialize = tmabilityDef.shouldInitialize;
                            if (shouldInitialize)
                            {
                                comp.RemovePawnAbility(tmabilityDef);
                                comp.AddPawnAbility(tmabilityDef, true, -1f);
                            }
                            comp.InitializeSpell();
                            i++;
                        }
                    }
                    i++;
                }
            }
            else
            {
                Hediff HD_F = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Frost"));
                HD_F.Severity += 0.3f;
            }
            killpawn(pawn1);
        }

       //分割线

    }
}