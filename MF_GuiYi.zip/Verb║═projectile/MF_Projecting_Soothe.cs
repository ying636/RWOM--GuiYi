﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;
using Verse.AI;

namespace MF_GuiYi
{
    class MF_Projecting_Soothe : Projectile_Ability
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn Targ_Pawn = hitThing as Pawn;
            Targ_Pawn.mindState.mentalStateHandler.Reset();
            Targ_Pawn.jobs.StopAll(false,true);

            base.Destroy(DestroyMode.Vanish); ;
        }

     }
}
