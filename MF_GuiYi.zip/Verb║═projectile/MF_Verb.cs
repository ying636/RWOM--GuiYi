﻿using System;
using AbilityUser;
using Verse;

namespace MF_GuiYi
{
	public class MF_Verb : Verb_UseAbility
	{
		public override bool CanHitTargetFrom(IntVec3 root, LocalTargetInfo targ)
		{
			Pawn Targ_P = targ.Thing as Pawn;
			bool flag = Targ_P != null && Targ_P.Downed || Targ_P.IsPrisoner;
			bool canTarget;
			if (flag)
			{
				canTarget = this.verbProps.targetParams.canTargetPawns;
			}
			else
			{
				canTarget = false;
			}
			return canTarget;
		}
	}
}