﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;
using Verse.AI;

namespace MF_GuiYi
{
    public class MF_Devour : Projectile_Ability
    {
        private void Mana_Add()
        {
            Pawn user = this.launcher as Pawn;
            Hediff HD = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Mana_Pure"));
            MF_Mana MF_Mana = HD as MF_Mana;
            MF_Mana.Severity += 0.01f;
        }
        protected override void Impact(Thing hitThing)
        {
            Pawn pawn = this.launcher as Pawn;
            Pawn pawn2 = hitThing as Pawn;
            Hediff Mana = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Mana_Pure"));
            CompAbilityUserMagic comp = pawn.GetComp<CompAbilityUserMagic>();
            CompAbilityUserMagic Target_Comp = pawn2.GetComp<CompAbilityUserMagic>();
            MF_Mana Comp_Mana = Mana as MF_Mana;
            bool flag = Target_Comp.IsMagicUser;
            bool flag1 = pawn2.story.traits.HasTrait(TraitDef.Named("Geomancer"));
            bool flag2 = pawn2.story.traits.HasTrait(TraitDef.Named("InnerFire"));
            bool flag3 = pawn2.story.traits.HasTrait(TraitDef.Named("HeartOfFrost")); 
            bool flag4 = pawn2.story.traits.HasTrait(TraitDef.Named("StormBorn"));
            bool flag5 = pawn2.story.traits.HasTrait(TraitDef.Named("TM_Brightmage"));
            //焰

            if (flag2)
            {
                AddHD(pawn,pawn2,comp,1);
                Mana_Add();
            }

            //霜

            if (flag3)
            {
                AddHD(pawn, pawn2, comp,2);
                Mana_Add();
            }
            //岩
            if (flag1)
            {
                AddHD(pawn, pawn2, comp,3);
                Mana_Add();
            }
            if (flag4) 
            {
                AddHD(pawn, pawn2, comp,4);
                Mana_Add();
            }
            if (flag5) 
            {
                AddHD(pawn, pawn2, comp, 5);
                Mana_Add();
            }

            //其他
                if (!flag)
                {
                    Comp_Mana.Severity += 0.01f;

                }
                if(flag && !flag1 && !flag2 && !flag3&&!flag4&&!flag5)
                {
                    Mana_Add();
                    killpawn(pawn2);
                }
            base.Destroy(DestroyMode.Vanish);
        }
        private void killpawn(Pawn pawn) 
        {
            CompAbilityUserMagic Target_Comp = pawn.GetComp<CompAbilityUserMagic>();
            Target_Comp.MagicUserLevel = 1;
            Target_Comp.MagicUserXP = 1;
            Target_Comp.MagicData.MagicAbilityPoints = 0;
            pawn.Kill(null, null);
        }

        private void AddHD(Pawn pawn,Pawn pawn1, CompAbilityUserMagic comp,int num)
        {
            TMAbilityDef AD = null;
            TMAbilityDef AD2 = null;
            string HD = null;
            if (num == 1)
            {
                HD = "MF_Fire";
                AD = MF_GYDefOf.MF_Fire;
                AD2 = TorannMagicDefOf.TM_Firebolt;
            }
            if (num == 2)
            {
                HD = "MF_Frost";
                AD = MF_GYDefOf.MF_Frost;
                AD2 = TorannMagicDefOf.TM_Icebolt;
            }
            if (num == 3)
            {
                HD = "MF_Earth";
                AD = MF_GYDefOf.MF_Earth;
                AD2 = TorannMagicDefOf.TM_Sentinel;
            }
            if (num == 4)
            {
                HD = "MF_Lightning";
                AD = MF_GYDefOf.MF_Lightning;
                AD2 = TorannMagicDefOf.TM_LightningBolt;
            }
            if (num == 5) 
            {
                HD = "MF_Bright";
                AD = MF_GYDefOf.MF_Bright;
                AD2 = null;
            }
            if (HD != null) 
            {
                if (!pawn.health.hediffSet.HasHediff(HediffDef.Named(HD)))
                {
                    pawn.health.AddHediff(HediffDef.Named(HD), null, null, null);
                    int i = 0;
                    while (i < comp.MagicData.AllMagicPowers.Count)
                    {
                        TMAbilityDef tmabilityDef = (TMAbilityDef)comp.MagicData.AllMagicPowers[i].abilityDef;
                        if (tmabilityDef == AD || tmabilityDef == AD2)
                        {
                            bool flag9 = !comp.MagicData.AllMagicPowers[i].learned;
                            if (flag9)
                            {
                                comp.MagicData.AllMagicPowers[i].learned = true;
                                bool shouldInitialize = tmabilityDef.shouldInitialize;
                                if (shouldInitialize)
                                {
                                    comp.RemovePawnAbility(tmabilityDef);
                                    comp.AddPawnAbility(tmabilityDef, true, -1f);
                                }
                                comp.InitializeSpell();
                                i++;
                            }
                        }
                        i++;
                    }
                }
                else
                {
                    Hediff HD_F = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named(HD));
                    HD_F.Severity += 0.3f;
                }
                killpawn(pawn1);
            }
        }
        //分割线

    }
}