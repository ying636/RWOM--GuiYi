﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_Bright_Projectile : Projectile_AbilityBase
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn pawn = launcher as Pawn;
            if (pawn.health.hediffSet.HasHediff(HediffDef.Named("MF_Bright")))
            {
                Hediff HD = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Bright"));
                MF_Bright HDC = HD.TryGetComp<MF_Bright>(); 
                if (HDC.number != 0)
                {
                    Map Map = base.Map;
                    IntVec3 Target_InVec3 = base.Position;
                    Thing sun = ThingMaker.MakeThing(MF_GYDefOf.MF_Sun, null);
                    sun.HitPoints += HDC.max() * 10;
                    CompSummoned sun_comp = sun.TryGetComp<CompSummoned>();
                    sun_comp.Temporary = true;
                    sun_comp.ticksToDestroy = 2000;
                    GenSpawn.Spawn(sun, Target_InVec3, Map, WipeMode.Vanish);
                    sun.SetFaction(pawn.Faction);
                    HDC.number--;
                }
                else 
                {
                    Messages.Message("MF_NoBright".Translate(), MessageTypeDefOf.NegativeEvent, true);
                }
            }
            base.Destroy(DestroyMode.Vanish); 
        }
     }
}