﻿using RimWorld;
using Verse;
using AbilityUser;
using TorannMagic;

namespace MF_GuiYi
{
	public class MF_Given : Verb_UseAbility
	{
		public override bool CanHitTargetFrom(IntVec3 root, LocalTargetInfo targ)
		{

			Pawn Targ_P = targ.Thing as Pawn;
			Hediff hediff = Targ_P.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Apostle"));
			MF_Contract hediff_Comp = hediff as MF_Contract;
			bool canTarget;
			if (
				Targ_P != null 
				&&
				Targ_P.health.hediffSet.HasHediff(HediffDef.Named("MF_Apostle")) 
				&& 
				hediff_Comp.Devourer == caster
				)
			{
				Pawn Launcher_Pawn = caster as Pawn;
				if (Launcher_Pawn.health.hediffSet.HasHediff(HediffDef.Named("MF_Element")))
				{
					Hediff HD = Launcher_Pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Element"));
					Launcher_Pawn.health.hediffSet.hediffs.Remove(HD);
					Trait TD = Targ_P.story.traits.GetTrait(TraitDef.Named("MF_DevourerApostle"));
					Targ_P.story.traits.allTraits.Remove(TD);
					Targ_P.story.traits.GainTrait(new Trait(TraitDef.Named("MF_ElementApostle"), 0, false));
					CompAbilityUserMagic comp = Targ_P.GetComp<CompAbilityUserMagic>();
					comp.InitializeSpell();
				}
				canTarget = true;
			}
			else
			{
			canTarget = false;
			}
			return canTarget;
		}
	}
}
