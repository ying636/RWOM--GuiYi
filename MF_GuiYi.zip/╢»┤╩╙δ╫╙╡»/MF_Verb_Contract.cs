﻿using TorannMagic;
using AbilityUser;
using Verse;
using RimWorld;

namespace MF_GuiYi
{
	public class MF_Verb_Contract : Verb_UseAbility
	{
		public override bool CanHitTargetFrom(IntVec3 root, LocalTargetInfo targ)
		{
			Pawn user = this.caster as Pawn;
			Pawn Targ_P = targ.Thing as Pawn;
			CompAbilityUserMagic comp = Targ_P.GetComp<CompAbilityUserMagic>();
			CompAbilityUserMight comp2 = Targ_P.GetComp<CompAbilityUserMight>();
			bool flag = Targ_P != null&& !comp.IsMagicUser&& !comp2.IsMightUser;
			bool canTarget;
			//目标非法师和战士
			if (flag)
			{
				Hediff HD = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Mana_Pure"));
				if (HD.Severity > 0.01f)
				{
					if (Targ_P.story.traits.HasTrait(TorannMagicDefOf.TM_Gifted))
					{
						Trait TD = Targ_P.story.traits.GetTrait(TorannMagicDefOf.TM_Gifted);
						Targ_P.story.traits.allTraits.Remove(TD);
					};


					if (Targ_P.story.traits.HasTrait(TorannMagicDefOf.PhysicalProdigy))
					{
						Trait TD = Targ_P.story.traits.GetTrait(TorannMagicDefOf.PhysicalProdigy);
						Targ_P.story.traits.allTraits.Remove(TD);
					};
					Targ_P.story.traits.GainTrait(new Trait(TraitDef.Named("MF_DevourerApostle"),0,false));
                    Hediff HD_C = HediffMaker.MakeHediff(HediffDef.Named("MF_Apostle"), Targ_P);
                    MF_Contract HD_C2 = HD_C as MF_Contract;
                    HD_C2.Devourer = user;
                    Targ_P.health.AddHediff(HD_C);
					HD.Severity -= 0.01f;
					canTarget =true;
				}
				else 
				{
					canTarget = false;
					Messages.Message("MF_NOMANA".Translate(), MessageTypeDefOf.NegativeEvent, true);
				}
			}
			//目标是法师
			else
			{
				canTarget = false;
				Messages.Message("MF_NO".Translate(), MessageTypeDefOf.NegativeEvent, true);
			}
            if (!user.health.hediffSet.HasHediff(HediffDef.Named("MF_Aura"))) 
			{
				user.health.AddHediff(HediffDef.Named("MF_Aura"));
			};
			return canTarget;
		}
	}
}