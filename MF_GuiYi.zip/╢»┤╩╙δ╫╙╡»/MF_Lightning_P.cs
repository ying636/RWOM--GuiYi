﻿using RimWorld;
using Verse;
using AbilityUser;

namespace MF_GuiYi
{
	public class MF_Lightning_P : Projectile_Ability
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn pawn = launcher as Pawn;
            Hediff HD = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Lightning"));
            MF_Lightning HDC = HD.TryGetComp<MF_Lightning>();
            if (HDC.number != 0)
            {
                IntVec3 pos = base.Position;
                Find.CurrentMap.weatherManager.eventHandler.AddEvent(new WeatherEvent_LightningStrike(Find.CurrentMap, pos));
                HDC.number--;
            }
            else 
            {
                Messages.Message("MF_NoLightning".Translate(), MessageTypeDefOf.NegativeEvent, true);
            }
            base.Destroy(DestroyMode.Vanish); 
        }
	}
}
