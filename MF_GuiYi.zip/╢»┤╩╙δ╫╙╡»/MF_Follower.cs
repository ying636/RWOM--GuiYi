﻿using RimWorld;
using Verse;
using AbilityUser;

namespace MF_GuiYi
{
	public class MF_Follower : Verb_UseAbility
	{
		public override bool CanHitTargetFrom(IntVec3 root, LocalTargetInfo targ)
		{
			Pawn Targ_P = targ.Thing as Pawn;
			Hediff hediff = Targ_P.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Apostle"));
			MF_Contract hediff_Comp = hediff as MF_Contract;
			bool canTarget;
			if (
				Targ_P != null 
				&&
				Targ_P.health.hediffSet.HasHediff(HediffDef.Named("MF_Apostle")) 
				&& 
				hediff_Comp.Devourer == caster
				&&
				Targ_P.InMentalState
				)
			{
			canTarget = true;
			}
			else
			{
			canTarget = false;
			}
			return canTarget;
		}
	}
}
