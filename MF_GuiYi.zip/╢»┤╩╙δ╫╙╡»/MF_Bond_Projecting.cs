﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_Bond_Projecting : Projectile_Ability
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn user = hitThing as Pawn;
            Pawn Launcher = launcher as Pawn;
            bool flag = user.health.hediffSet.HasHediff(HediffDef.Named("MF_Fire"))&& user.health.hediffSet.HasHediff(HediffDef.Named("MF_Frost"))
            && user.health.hediffSet.HasHediff(HediffDef.Named("MF_Earth")) && user.health.hediffSet.HasHediff(HediffDef.Named("MF_Lightning"))
            && user.health.hediffSet.HasHediff(HediffDef.Named("MF_Bright"));
            if (flag&&!user.health.hediffSet.HasHediff(HediffDef.Named("MF_Element"))) 
            {
                Hediff HD = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Fire"));
                Hediff HD2 = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Frost"));
                Hediff HD3 = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Earth"));
                Hediff HD4 = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Lightning"));
                Hediff HD5 = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Bright"));
                if (HD.Severity == 1f && HD2.Severity == 1f && HD3.Severity == 1f && HD4.Severity == 1f && HD5.Severity == 1f) 
                {
                    HD.Severity = 0.1f;
                    HD2.Severity = 0.1f;
                    HD3.Severity = 0.1f;
                    HD4.Severity = 0.1f;
                    HD5.Severity = 0.1f;
                    user.health.AddHediff(HediffDef.Named("MF_Element"));

                    CompAbilityUserMagic comp = Launcher.GetComp<CompAbilityUserMagic>();
                    for (int i = 0; i < comp.MagicData.AllMagicPowers.Count; i++)
                    {
                        TMAbilityDef tmabilityDef = (TMAbilityDef)comp.MagicData.AllMagicPowers[i].abilityDef;
                        if (tmabilityDef == MF_GYDefOf.MF_Element)
                        {
                            bool flag9 = !comp.MagicData.AllMagicPowers[i].learned;
                            if (flag9)
                            {
                                comp.MagicData.AllMagicPowers[i].learned = true;
                                bool shouldInitialize = tmabilityDef.shouldInitialize;
                                if (shouldInitialize)
                                {
                                    comp.RemovePawnAbility(tmabilityDef);
                                    comp.AddPawnAbility(tmabilityDef, true, -1f);
                                }
                                comp.InitializeSpell();
                            }
                        }

                    }

                }
            }

            base.Destroy(DestroyMode.Vanish); 
        }
     }
}
