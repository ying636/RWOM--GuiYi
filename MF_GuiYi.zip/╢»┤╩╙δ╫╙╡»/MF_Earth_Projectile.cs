﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_Earth_Projectile : Projectile_AbilityBase
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn pawn = launcher as Pawn;
            if (pawn.health.hediffSet.HasHediff(HediffDef.Named("MF_Earth")))
            {
                Hediff HD = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Earth"));
                MF_Earth HDC = HD.TryGetComp<MF_Earth>();
                if (HDC.number != 0)
                {
                    Map Map = base.Map;
                    IntVec3 Target_InVec3 = base.Position;
                    Thing Wall = ThingMaker.MakeThing(ThingDefOf.RaisedRocks, null);
                    Wall.HitPoints += HDC.max() * 10;

                    GenSpawn.Spawn(Wall, Target_InVec3, Map, WipeMode.Vanish);
                    HDC.number--;
                }
                else 
                {
                    Messages.Message("MF_NoEarth".Translate(), MessageTypeDefOf.NegativeEvent, true);
                }
            }
            base.Destroy(DestroyMode.Vanish); 
        }
     }
}