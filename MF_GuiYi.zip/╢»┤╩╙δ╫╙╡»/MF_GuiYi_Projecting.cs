﻿using Verse;
using AbilityUser;
using RimWorld;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_GuiYi_Projecting : Projectile_AbilityBase
    {
        protected override void Impact(Thing hitThing)
        {
            Pawn Target_Pawn = hitThing as Pawn;
            float num = new FloatRange(1f, 5f).RandomInRange + 10f;
            if (Target_Pawn!=null) 
            {
                Target_Pawn.TakeDamage(new DamageInfo(DamageDefOf.Stun, num, 0f, 0f, this.launcher, null, null, DamageInfo.SourceCategory.ThingOrUnknown, Target_Pawn));
                Target_Pawn.TakeDamage(new DamageInfo(MF_GYDefOf.TM_Arcane, num, 0f, 0f, this.launcher, null, null, DamageInfo.SourceCategory.ThingOrUnknown, Target_Pawn));
            }
            base.Destroy(DestroyMode.Vanish); ;
        }
     }
}