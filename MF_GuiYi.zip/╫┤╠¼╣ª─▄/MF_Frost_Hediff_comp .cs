﻿using Verse;
using System;
using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using TorannMagic;

namespace MF_GuiYi
{
    class MF_Frost_Hediff_Comp : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
            {
            if (isProjected == true)
            { 
                time++;
                Map Pawn_Map = Pawn.Map;
                if (time > 5000)
                {
                time = 0;
                    for (int i = 0; i < Pawn_Map.mapPawns.AllPawnsCount; i++)
                    {
                        Pawn P1 = Pawn_Map.mapPawns.AllPawns[i];
                        if (P1 != null && P1.Faction != null && !P1.Faction.IsPlayer)
                        {
                            bool flag = P1.Faction.RelationWith(Pawn.Faction).kind == FactionRelationKind.Hostile;
                            bool flag2 = P1.Position.InHorDistOf(Pawn.Position, Radius());
                            if (flag && flag2)
                            {
                                Hediff Heatstroke = P1.health.hediffSet.GetFirstHediffOfDef(HediffDefOf.Hypothermia);
                                //低温
                                if (Heatstroke != null)
                                {
                                    Heatstroke.Severity += 0.00001f;
                                }
                                else
                                {
                                    P1.health.AddHediff(HediffDefOf.Hypothermia);
                                }
                                //伤害
                                for (int ia = 0; ia < number; ia++)
                                {
                                    float num = new FloatRange(1f, 5f).RandomInRange;
                                    num += damage;
                                    DamageInfo Fire_Damage = new DamageInfo(DamageDefOf.Frostbite, num, 0f, 0f, this.Pawn, null, null, DamageInfo.SourceCategory.ThingOrUnknown, P1);
                                    P1.TakeDamage(Fire_Damage);
                                }
                            }
                        }
                    }
                }
            }
            }
        public float Radius() 
        {
            float Radius_a = 10f;
            if (parent.Severity > 0.3f) 
            {
                Radius_a += 4f;
            }
            if (parent.Severity > 0.6f)
            {
                Radius_a += 4f;
            }
            if (parent.Severity >= 1f)
            {
                Radius_a += 4f;
            }
            return Radius_a;
        }
        public int time = 0;
        public int number = 3;
        public float damage = 1f;
        public bool isProjected = false;
    }
}
