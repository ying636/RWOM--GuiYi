﻿using Verse;
using System;
using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using TorannMagic;

namespace MF_GuiYi
{

    class MF_Hediff_Aura : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
        {
            time++;
            if (time > 10000) 
            {
                for (int i =0;i<Pawn.Map.mapPawns.AllPawnsCount;i++) 
                {
                    Pawn P = Pawn.Map.mapPawns.AllPawns[i];
                    if (P.health.hediffSet.HasHediff(HediffDef.Named("MF_Follower"))&&P!=null)
                    {
                        Hediff HD = P.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Follower"));
                        MF_Contract HD_Comp = HD as MF_Contract;
                        if (HD_Comp.Devourer == Pawn&&P.Position.InHorDistOf(Pawn.Position,45f)) 
                        {
                            num++;
                        }
                    }
                }
                severity(num);
                time = 0;
                num = 0;
            }
        }
        public void severity(int num) 
        {
            if (num>3|| num==3)
            {
                severity_m = 0.3f;
            };
            if (num > 5 || num == 5)
            {
                severity_m = 0.6f;
            };
            if (num > 7 || num == 7)
            {
                severity_m = 0.9f;
            };
            if (num > 10 || num == 10)
            {
                severity_m = 1f;
            };
            this.parent.Severity = severity_m;
        }
        public float severity_m = 0.1f;
        public int time = 0;
        public int num = 0;
    }
}
