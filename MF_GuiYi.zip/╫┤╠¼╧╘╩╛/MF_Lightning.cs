﻿using System;
using Verse;
using RimWorld;
using System.Text;
using System.Threading.Tasks;

namespace MF_GuiYi
{
    public class MF_Lightning : HediffComp
    {
        public override string CompLabelInBracketsExtra => "MF_Lightning".Translate()+number.ToString();
        public override void CompPostTick(ref float severityAdjustment)
        {
         if (number < max())
         {
          time++;
          if (time> TOE) 
          {

              number++;
              time = 0;
          }
         }
        }
        public int max() 
        {
           float severity = this.parent.Severity;
           int max = 3;
            if (severity>0.3f|| severity==0.3f) { max = 5; }
            if (severity > 0.6f || severity == 0.6f) { max = 7; }
            if (severity > 0.9f || severity == 0.9f) { max = 9; }
            if (severity > 1f || severity == 1f) { max = 11; }
            return max;
        }
        public int number = 0;
        public int time = 0;
        public int TOE = 500;
    }
}
