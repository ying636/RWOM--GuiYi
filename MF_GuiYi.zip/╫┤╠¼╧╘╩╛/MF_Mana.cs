﻿using RimWorld;
using Verse;
using System.Text;

namespace MF_GuiYi
{
    class MF_Mana : HediffWithComps
    {
		public override string LabelInBrackets
		{
			get
			{
				float a = Severity * 100;
				return a.ToString() +"ea";
			}
		}
    }
}
