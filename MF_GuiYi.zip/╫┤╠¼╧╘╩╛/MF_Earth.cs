﻿using System;
using Verse;
using RimWorld;
using System.Text;
using System.Threading.Tasks;

namespace MF_GuiYi
{
    public class MF_Earth : HediffComp
    {
        public override string CompLabelInBracketsExtra => "MF_Earth".Translate()+number.ToString();
        public override void CompPostTick(ref float severityAdjustment)
        {
         if (number < max())
         {
          time++;
          if (time> TOE) 
          {
              number++;
              time = 0;
          }
         }
        }
        public int max() 
        {
           float severity = this.parent.Severity;
           int max = 4;
            if (severity>0.3f|| severity==0.3f) { max = 8; }
            if (severity > 0.6f || severity == 0.6f) { max = 12; }
            if (severity > 0.9f || severity == 0.9f) { max = 16; }
            if (severity > 1f || severity == 1f) { max = 20; }
            return max;
        }
        public int number = 0;
        public int time = 0;
        public int TOE = 250;
    }
}
