﻿using RimWorld;
using Verse;
using System.Text;

namespace MF_GuiYi
{
    class MF_Frost_Hediff : HediffWithComps
    {

        public override string TipStringExtra
        {
            get
            {
                Hediff HD = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("MF_Frost"));
                MF_Frost_Hediff_Comp C1 = HD.TryGetComp<MF_Frost_Hediff_Comp>();
                string range = "MF_Radius".Translate()+C1.Radius();
                string number = "MF_Number".Translate() + C1.number;
                string tick = "MF_time".Translate() + C1.time +"/5000";
                StringBuilder tip = new StringBuilder();
                tip.Append(base.TipStringExtra);
                tip.AppendLine("-----------------");
                tip.AppendLine(range);
                tip.AppendLine(number);
                tip.AppendLine(tick);
                string isProjected;
                if (C1.isProjected)
                {
                    isProjected = "MF_Projected".Translate();
                }
                else
                {
                    isProjected = "MF_notProjected".Translate();
                }
                tip.AppendLine(isProjected);
                tip.AppendLine("-----------------");
                return tip.ToString();
            }
        }
    }
}
