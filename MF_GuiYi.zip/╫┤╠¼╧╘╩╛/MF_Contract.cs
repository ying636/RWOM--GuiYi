﻿using RimWorld;
using Verse;
using System.Text;

namespace MF_GuiYi
{
    class MF_Contract : HediffWithComps
    {
		public override void ExposeData()
		{
			base.ExposeData();
			Scribe_References.Look(ref Devourer, "Devourer", false);
		}
		public override string LabelInBrackets
		{
			get
			{
				if (Devourer == null)
				{
					return null;
				}
				else
				{
					return Devourer.Label;
				}
			}
		}
		public Pawn Devourer = null;
	}
}
