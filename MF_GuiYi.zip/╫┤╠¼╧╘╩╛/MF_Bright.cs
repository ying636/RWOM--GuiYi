﻿using System;
using Verse;
using RimWorld;

namespace MF_GuiYi
{
    public class MF_Bright : HediffComp
    {
        public override string CompLabelInBracketsExtra => "MF_Bright".Translate()+number.ToString();
        public override void CompPostTick(ref float severityAdjustment)
        {
            if (number < max())
            {
                float num = GenLocalDate.DayPercent(this.Pawn.Map);
                if (num > day()) 
                {
                    time++;
                    if (time > TOE)
                    {
                        number++;
                        time = 0;
                    }
                }
            }
        }
        public int max() 
        {
           float severity = this.parent.Severity;
           int max = 1;
            if (severity>0.3f|| severity==0.3f) { max = 2; }
            if (severity > 0.6f || severity == 0.6f) { max = 3; }
            if (severity > 0.9f || severity == 0.9f) { max = 4; }
            if (severity > 1f || severity == 1f) { max = 5; }
            return max;
        }
        public int number = 0;
        public int time = 0;
        public int TOE = 2500;
        public float day() 
        {
            float severity = this.parent.Severity;
            float day = 1;
            if (severity > 0.3f || severity == 0.3f) { day = 1f; }
            if (severity > 0.6f || severity == 0.6f) { day = 0.8f; }
            if (severity > 0.9f || severity == 0.9f) { day = 0.4f; }
            if (severity > 1f || severity == 1f) { day = 0f; }
            return day;
        }
    }
}
